public final class Lesson2_4
{
    public static void main(String[] args)
    {
        SomeObject someObject1, someObject2;
        char c1, c2;

        c1 = 'A';
        c2 = 'A';
        // 'A'== 'A'
        if(c1 == c2)
        {
            System.out.println("c1 == c2");
        }
        else
        {
            System.out.println("c1 != c2");
        }
        
        someObject1 = new SomeObject("My Object", 123L);
        someObject2 = new SomeObject("My Object", 123L);

        // @0x01234567 == @0x09876543
        if(someObject1 == someObject2)
        {
            System.out.println("someObject1 == someObject2");
        }
        else
        {
            System.out.println("someObject1 != someObject2");
        }
    }
}
