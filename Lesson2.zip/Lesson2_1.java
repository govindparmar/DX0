public final class Lesson2_1
{
    public static void main(String[] args)
    {
        SomeObject someObject = new SomeObject();
        System.out.println("New SomeObject = " + someObject);
        someObject = new SomeObject("A string", 1234L);
        System.out.println("Another new SomeObject = " + someObject);
    }
}
