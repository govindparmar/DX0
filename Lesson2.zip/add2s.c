#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <strsafe.h>
#include <sal.h>

#define WMain wmain

WCHAR* WINAPI AddTwoStrings(_In_z_ WCHAR *wszFirst, _In_z_ WCHAR *wszSecond)
{
	CONST HANDLE hHeap = GetProcessHeap();
	HRESULT hr;
#ifdef _WIN64
	UINT64
#else
	UINT32
#endif
	uLen1, uLen2;
	SIZE_T cbAlloc;
	WCHAR *pNewString = NULL;
	
	hr = StringCbLengthW(wszFirst, STRSAFE_MAX_CCH * sizeof(WCHAR), &uLen1);
	if(FAILED(hr))
	{
		return NULL;
	}
	
	hr = StringCbLengthW(wszSecond, STRSAFE_MAX_CCH * sizeof(WCHAR), &uLen2);
	if(FAILED(hr))
	{
		return NULL;
	}
	
	cbAlloc = uLen1 + uLen2;
	if(0 == cbAlloc)
	{
		return NULL;
	}
	
	pNewString = (WCHAR *)HeapAlloc(hHeap, HEAP_ZERO_MEMORY, cbAlloc + sizeof(WCHAR));
        if(NULL == pNewString)
        {
                return NULL;
        }
        
        StringCbCopyW(pNewString, cbAlloc + sizeof(WCHAR), wszFirst);
        StringCbCatW(pNewString, cbAlloc + sizeof(WCHAR), wszSecond);
        
        return pNewString;
}
	

INT WINAPIV WMain(_In_ INT nArgc, _In_reads_(nArgc) WCHAR *pArgv[])
{
	CONST HANDLE hHeap = GetProcessHeap();
	WCHAR *pNewString = NULL;
	DWORD dwError;

	if(nArgc < 3)
	{
		_putws(L"Usage: add2s str1 str2");
		return 0;
	}
	
	pNewString = AddTwoStrings(pArgv[1], pArgv[2]);
	if(NULL == pNewString)
	{
		dwError = GetLastError();	
		fwprintf(stderr, L"Could not add strings: %I32u\n", dwError);
		return (INT) dwError;
	}

	wprintf(L"%s\n", pNewString);
	HeapFree(hHeap, 0, pNewString);
	pNewString = NULL;
	
	return 0;
}
