public final class SomeObject
{
    private final String aString;
    private final long aLong;
    
    public SomeObject()
    {
        aString = "";
        aLong = 0L;
    }
    
    public SomeObject(final String aString, final long aLong)
    {
        this.aString = aString;
        this.aLong = aLong;
    }
    
    public String toString()
    {
        return aString + ", " + aLong;
    }
}
